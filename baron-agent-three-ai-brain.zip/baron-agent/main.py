"""
اجرای مستقیم از خط فرمان، برای تست پایپ‌لاین قبل از وصل کردن به تلگرام.

استفاده:
    python main.py "loss aversion in new traders"
یا بدون آرگومان:
    python main.py
    (بعد نیچ رو بهت می‌پرسه)
"""
import argparse
import asyncio
import json
import logging

import config
import pipeline

logging.basicConfig(level=logging.INFO)


async def _main() -> None:
    parser = argparse.ArgumentParser(description="Baron Finance Content Agent")
    parser.add_argument("niche", nargs="?", help="نیچ یا موضوع محتوا")
    args = parser.parse_args()

    config.validate_config()

    niche = args.niche or input("نیچ/موضوع محتوا رو وارد کن: ").strip()
    if not niche:
        print("نیچ خالیه، خارج میشم.")
        return

    print(f"\nدر حال ساخت محتوا برای نیچ: {niche} ...\n")
    result = await pipeline.run_full_pipeline(niche)

    print("=== تحلیل نیچ ===")
    print(json.dumps(result["analysis"], ensure_ascii=False, indent=2))

    print("\n=== اسکریپت نهایی ===")
    print(result["script"])

    print("\n=== کپشن نهایی ===")
    print(result["caption"])

    with open("output.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print("\nنتیجه‌ی کامل در output.json ذخیره شد.")


if __name__ == "__main__":
    asyncio.run(_main())
