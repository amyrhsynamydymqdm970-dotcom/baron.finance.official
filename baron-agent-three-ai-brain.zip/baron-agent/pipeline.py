"""
قلب پروژه — منطق مرحله‌ای:
تحلیل نیچ -> هوک -> بدنه -> پایان‌بندی -> کپشن
هر مرحله: سه مدل همزمان صدا زده میشن -> نتایج به داور داده میشه -> نتیجه‌ی
قفل‌شده به مرحله‌ی بعد پاس داده میشه.
"""
import json
import logging

import call_models
import prompts

logger = logging.getLogger(__name__)


async def analyze_niche(niche: str) -> dict:
    prompt = prompts.NICHE_ANALYSIS_PROMPT.format(niche=niche)
    outputs = await call_models.ask_all_models(prompt, system=prompts.CONTENT_BRAIN_SYSTEM)
    raw = await call_models.synthesize(prompt, outputs, system=prompts.CONTENT_BRAIN_SYSTEM)

    cleaned = raw.strip()
    # اگه مدل توی Markdown code block جواب داده باشه، پاکش کن
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:]

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        logger.warning("تحلیل نیچ به‌صورت JSON برنگشت، متن خام نگه داشته شد")
        return {"raw": raw}


async def _run_stage(
    stage_prompt: str, judge_prompt_template: str, context: dict
) -> str:
    raw_outputs = await call_models.ask_all_models(
        stage_prompt, system=prompts.CONTENT_BRAIN_SYSTEM
    )
    outputs_text = "\n\n".join(
        f"خروجی {name}:\n{text}" for name, text in raw_outputs.items() if text
    )

    if not outputs_text:
        raise RuntimeError("هیچ‌کدوم از سه مدل جواب ندادن — کلیدهای API رو چک کن")

    judge_prompt = judge_prompt_template.format(outputs=outputs_text, **context)
    final_text = await call_models.synthesize(
        judge_prompt, raw_outputs, system=prompts.JUDGE_BRAIN_SYSTEM
    )
    return final_text.strip()


async def run_full_pipeline(niche: str) -> dict:
    analysis = await analyze_niche(niche)
    analysis_json = json.dumps(analysis, ensure_ascii=False)

    # مرحله ۱: هوک
    hook_prompt = prompts.HOOK_PROMPT.format(niche=niche, analysis=analysis_json)
    hook_final = await _run_stage(
        hook_prompt, prompts.JUDGE_HOOK_TEMPLATE, {"niche": niche}
    )

    # مرحله ۲: بدنه
    body_prompt = prompts.BODY_PROMPT.format(hook=hook_final)
    body_final = await _run_stage(
        body_prompt, prompts.JUDGE_BODY_TEMPLATE, {"hook": hook_final}
    )

    # مرحله ۳: پایان‌بندی
    ending_prompt = prompts.ENDING_PROMPT.format(hook=hook_final, body=body_final)
    ending_final = await _run_stage(
        ending_prompt,
        prompts.JUDGE_ENDING_TEMPLATE,
        {"hook": hook_final, "body": body_final},
    )

    full_script = f"{hook_final}\n\n{body_final}\n\n{ending_final}"

    # مرحله ۴: کپشن
    caption_prompt = prompts.CAPTION_PROMPT.format(script=full_script)
    caption_final = await _run_stage(
        caption_prompt, prompts.JUDGE_CAPTION_TEMPLATE, {"script": full_script}
    )

    return {
        "niche": niche,
        "analysis": analysis,
        "hook": hook_final,
        "body": body_final,
        "ending": ending_final,
        "script": full_script,
        "caption": caption_final,
    }
