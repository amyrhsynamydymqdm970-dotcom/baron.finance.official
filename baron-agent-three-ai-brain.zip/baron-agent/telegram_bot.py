"""Telegram interface for the Baron three-model ensemble."""
import logging

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, MessageHandler, filters

import config
import pipeline

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "سلام! من Baron Brain هستم.\n\n"
        "هر موضوعی بفرستی، هر سه موتور هوش مصنوعی — Gemini، Claude و Perplexity — "
        "همزمان آن را بررسی می‌کنند و بعد مغز متفکر Baron بهترین خروجی مشترک را می‌سازد.\n\n"
        "تو لازم نیست هیچ مدلی را انتخاب کنی."
    )


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    niche = (update.message.text or "").strip()
    if not niche:
        return

    processing_msg = await update.message.reply_text(
        "🧠 Baron Brain در حال بررسی موضوع با ۳ هوش مصنوعی است...\n"
        "Gemini + Claude + Perplexity → ترکیب و داوری نهایی"
    )

    try:
        result = await pipeline.run_full_pipeline(niche)
        reply = (
            f"🎬 اسکریپت نهایی:\n{result['script']}\n\n"
            f"📝 کپشن:\n{result['caption']}"
        )
        if len(reply) > 4000:
            await processing_msg.edit_text(reply[:4000])
            await update.message.reply_text(reply[4000:])
        else:
            await processing_msg.edit_text(reply)
    except Exception as exc:
        logger.exception("خطا در پردازش پیام")
        await processing_msg.edit_text(
            "❌ در اجرای Baron Brain خطایی رخ داد.\n\n" + str(exc)
        )


def main() -> None:
    config.validate_config(require_telegram=True)
    app = ApplicationBuilder().token(config.TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    logger.info("Baron three-model agent is running...")
    app.run_polling()


if __name__ == "__main__":
    main()
