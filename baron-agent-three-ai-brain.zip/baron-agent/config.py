"""Central configuration for the Baron multi-model ensemble."""
import os
from dotenv import load_dotenv

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
PUTER_AUTH_TOKEN = os.getenv("PUTER_AUTH_TOKEN")

# These are intentionally fixed as the three hidden workers. The user does not choose one.
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5")
PERPLEXITY_MODEL = os.getenv("PERPLEXITY_MODEL", "perplexity/sonar")

# Baron Brain uses one of the same three models only as the final synthesizer.
# This is an internal implementation detail, not a user-facing selector.
JUDGE_MODEL = os.getenv("JUDGE_MODEL", "gemini-2.5-flash")
AI_TIMEOUT = int(os.getenv("AI_TIMEOUT", "180"))


def validate_config(require_telegram: bool = False) -> None:
    missing = []
    if not PUTER_AUTH_TOKEN:
        missing.append("PUTER_AUTH_TOKEN")
    if require_telegram and not TELEGRAM_BOT_TOKEN:
        missing.append("TELEGRAM_BOT_TOKEN")
    if missing:
        raise EnvironmentError("Missing environment variables: " + ", ".join(missing))
