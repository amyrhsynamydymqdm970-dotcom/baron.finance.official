# Baron Finance Agent — 3 AI Ensemble + Baron Brain

This version implements the requested architecture:

USER → Baron Bot → **Gemini + Claude + Perplexity in parallel** → **Baron Brain** → ONE final answer.

The user never chooses a model. Every question/task goes to all three workers.
The hidden Baron Brain receives all three outputs, compares them, resolves conflicts,
keeps the strongest evidence/ideas, and returns one final answer.

## Models
- Gemini 2.5 Flash
- Claude Sonnet 5
- Perplexity Sonar

## Why Puter.js is used here
The bot is Python/Telegram, while Puter.js is JavaScript. The project therefore
runs a tiny Node.js bridge (`puter_bridge.mjs`) using the official Puter.js npm
package. The Python pipeline calls that bridge. Puter documents Node.js usage with
`init(authToken)` and `puter.ai.chat()`.

You need a `PUTER_AUTH_TOKEN`, not the Gemini/Claude/Perplexity API keys, for this
Puter-backed architecture.

## Setup

```bash
npm install
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Set:

```text
TELEGRAM_BOT_TOKEN=...
PUTER_AUTH_TOKEN=...
```

Then:

```bash
python telegram_bot.py
```

For Docker:

```bash
docker build -t baron-agent .
docker run --env-file .env baron-agent
```

## Pipeline

Even the niche-analysis step now uses all three models before the hidden Baron Brain
synthesizes it. Every later stage does the same:

three models → synthesis → next stage.

The final response shown to the user contains only the synthesized Baron answer,
not the three raw provider answers.
