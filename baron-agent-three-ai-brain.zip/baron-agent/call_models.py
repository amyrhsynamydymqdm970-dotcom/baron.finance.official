"""Three-model ensemble through Puter.js + a hidden Baron Brain synthesizer."""
import asyncio
import json
import logging
import os
from pathlib import Path

import config

logger = logging.getLogger(__name__)
ROOT = Path(__file__).resolve().parent
BRIDGE = ROOT / "puter_bridge.mjs"


def _run_bridge(prompt: str, system: str | None = None) -> dict:
    payload = {
        "prompt": prompt,
        "system": system or "",
        "models": {
            "gemini": config.GEMINI_MODEL,
            "claude": config.CLAUDE_MODEL,
            "perplexity": config.PERPLEXITY_MODEL,
        },
    }
    env = os.environ.copy()
    if not env.get("PUTER_AUTH_TOKEN"):
        raise RuntimeError("PUTER_AUTH_TOKEN is not configured")

    proc = __import__("subprocess").run(
        ["node", str(BRIDGE), json.dumps(payload, ensure_ascii=False)],
        cwd=str(ROOT),
        env=env,
        capture_output=True,
        text=True,
        timeout=config.AI_TIMEOUT,
    )
    if proc.returncode != 0:
        detail = proc.stderr.strip() or proc.stdout.strip()
        raise RuntimeError(f"Puter bridge failed: {detail}")
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Invalid Puter bridge response: {proc.stdout[:1000]}") from exc
    if data.get("error"):
        raise RuntimeError(data["error"])
    return data.get("results", {})


async def ask_all_models(prompt: str, system: str | None = None) -> dict:
    """Every user/task prompt is sent to Gemini, Claude and Perplexity."""
    return await asyncio.to_thread(_run_bridge, prompt, system)


async def synthesize(prompt: str, outputs: dict, system: str | None = None) -> str:
    """Hidden Baron Brain: combine exactly the three answers already produced."""
    valid = {k: v for k, v in outputs.items() if isinstance(v, str) and v.strip()}
    if not valid:
        raise RuntimeError(f"All three AI models failed: {outputs}")

    synthesis_prompt = f"""You are the hidden final reasoning brain of Baron Finance.
You are NOT choosing a provider. You are synthesizing the independent answers below.
Use their strongest ideas, correct contradictions, reject weak claims, and produce ONE
best answer. Do not mention Gemini, Claude, Perplexity, providers, or this synthesis
process in your final answer unless explicitly asked.

USER/TASK:
{prompt}

INDEPENDENT ANSWERS:
--- GEMINI ---
{valid.get('gemini', '(no answer)')}

--- CLAUDE ---
{valid.get('claude', '(no answer)')}

--- PERPLEXITY ---
{valid.get('perplexity', '(no answer)')}

Now produce the single best answer. Follow the system instructions and preserve
Baron's content rules. Do not blindly average the answers: reason over them."""

    return (await asyncio.to_thread(
        _run_single_model, synthesis_prompt, system, config.JUDGE_MODEL
    )).strip()


async def ask_judge(prompt: str, system: str | None = None) -> str:
    """Backward-compatible helper: obtain three answers, then synthesize them."""
    outputs = await ask_all_models(prompt, system)
    return await synthesize(prompt, outputs, system)


def _run_single_model(prompt: str, system: str | None, model_name: str) -> str:
    payload = {
        "prompt": prompt,
        "system": system or "",
        "models": {"judge": model_name},
    }
    env = os.environ.copy()
    if not env.get("PUTER_AUTH_TOKEN"):
        raise RuntimeError("PUTER_AUTH_TOKEN is not configured")
    proc = __import__("subprocess").run(
        ["node", str(BRIDGE), json.dumps(payload, ensure_ascii=False)],
        cwd=str(ROOT), env=env, capture_output=True, text=True, timeout=config.AI_TIMEOUT,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or proc.stdout.strip())
    data = json.loads(proc.stdout)
    if data.get("error"):
        raise RuntimeError(data["error"])
    value = data.get("results", {}).get("judge", "")
    if isinstance(value, dict):
        raise RuntimeError(value.get("error", "Judge model failed"))
    return value
