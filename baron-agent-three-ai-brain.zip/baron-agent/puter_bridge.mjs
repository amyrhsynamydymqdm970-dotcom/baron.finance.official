import { init } from '@heyputer/puter.js/src/init.cjs';

const authToken = process.env.PUTER_AUTH_TOKEN;
if (!authToken) {
  console.error(JSON.stringify({ error: 'PUTER_AUTH_TOKEN is not configured' }));
  process.exit(2);
}

const puter = init(authToken);
const payload = JSON.parse(process.argv[2] || '{}');
const prompt = String(payload.prompt || '');
const system = payload.system ? String(payload.system) : '';
const models = payload.models || {};

if (!prompt) {
  console.error(JSON.stringify({ error: 'prompt is required' }));
  process.exit(2);
}

function messagesFor(promptText, systemText) {
  const messages = [];
  if (systemText) messages.push({ role: 'system', content: systemText });
  messages.push({ role: 'user', content: promptText });
  return messages;
}

function contentToText(content) {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) {
    return content.map(x => typeof x === 'string' ? x : (x?.text || '')).join('');
  }
  return '';
}

async function ask(model) {
  const response = await puter.ai.chat(
    messagesFor(prompt, system),
    false,
    { model, normalize: true }
  );
  return contentToText(response?.message?.content) || contentToText(response?.content) || '';
}

async function main() {
  const entries = Object.entries(models);
  const settled = await Promise.allSettled(entries.map(([, model]) => ask(model)));
  const result = {};
  for (let i = 0; i < entries.length; i++) {
    const [name] = entries[i];
    const item = settled[i];
    result[name] = item.status === 'fulfilled'
      ? item.value
      : { error: item.reason?.message || String(item.reason) };
  }
  process.stdout.write(JSON.stringify({ results: result }));
}

main().catch(err => {
  process.stdout.write(JSON.stringify({ error: err?.message || String(err) }));
  process.exit(1);
});
